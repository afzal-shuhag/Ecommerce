@extends('frontend.layouts.master')

@section('content')
  <div class="container margin-top-20">
    <h2>Contact</h2>
    <p>Loremipsum dolor smit ansu fati tere amafi diaji afgyhdagt turamma</p>
  </div>
@endsection
