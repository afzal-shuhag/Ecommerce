<footer class="footer-bottom">
  <p class="text-center">&copy; 2020 All rights reserved || Ecommerce</p>
</footer>
