

<?php $__env->startSection('content'); ?>
<!-- Start of Siderbar + content -->

<div class="our-slider mb-5">
  <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
      <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($loop->index); ?>" class="<?php echo e($loop->index == 2 ? 'active' : ''); ?>">
      </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ol>
    <div class="carousel-inner">
    <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="carousel-item  <?php echo e($loop->index == 2 ? 'active' : ''); ?> mt-3 mb-3">
      <img class="d-block w-100" src="<?php echo e(asset('images/sliders/'.$slider->image)); ?>" alt="First slide">
      <div class="carousel-caption d-none d-md-block">
        <h4><?php echo e($slider->title); ?></h4>
        <p>
          <?php if($slider->button_text): ?>
            <a href="<?php echo e($slider->button_link); ?>" target="_blank" class="btn btn-danger"><?php echo e($slider->button_text); ?></a>
          <?php endif; ?>
        </p>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</div>


  <div class="container margin-top-20">

    <div class="row">
      <div class="col-md-4">
        <?php echo $__env->make('frontend.partials.product-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>

      <div class="col-md-8">
          <div class="widget">
            <h3>All Products</h3>
            <?php echo $__env->make('frontend.pages.product.partials.all_products', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </div>
      </div>
    </div>
  </div>

<!-- End of Siderbar + Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ecommerce\resources\views/frontend/pages/index.blade.php ENDPATH**/ ?>