<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Invoice -- <?php echo e($order->id); ?></title>
    <link rel="stylesheet" href=" <?php echo e(asset('css/admin_style.css')); ?> ">
    <style media="screen">
      .invoice-header{
        padding: 10px 20px;
        background: burlywood;
        border-bottom: 1px solid;
      }
    </style>
  </head>
  <body>

      <div class="content-wrapper">
        <div class="invoice-header">
          <div class="float-left site-logo">
            <img src="<?php echo e(asset('images/favicon.png')); ?>" alt="">
          </div>
          <div class="float-right site-address">
            <h4>Ecommerce Shop</h4>
            <p>Address : <a href="#">Tilagor, 156, Sylhet</a> </p>
            <p>Phone : <a href="#">+880166836264</a> </p>
            <p>Email : <a href="#">demo@gmail.com</a> </p>
          </div>
          <div class="clearfix"></div>

        </div>
        <div class="invoice-description">
          <div class="invoice-left-top float-left">
            <p> <strong>Orderer Name : </strong> <?php echo e($order->name); ?></p>
            <p> <strong>Orderer Phone : </strong> <?php echo e($order->phone_no); ?></p>
            <p> <strong>Orderer Email : </strong> <?php echo e($order->email); ?></p>
            <p> <strong>Orderer shipping Address : </strong> <?php echo e($order->shipping_address); ?></p>
            <p> <strong>Orderer Name : </strong> <?php echo e($order->name); ?></p>
          </div>
          <div class="invoice-right-top float-right">
            <h3>Invoice - #<?php echo e($order->id); ?></h3>
            <p><?php echo e($order->created_at); ?></p>
          </div>
          <div class="clearfix"></div>
        </div>
        <div class="card-body">
            <h3>Products</h3>
            <hr>
            <?php if($order->carts->count() > 0): ?>
            <table class="table table-bordered table-striped">
              <thead>
                <tr>
                  <th>No.</th>
                  <th>Product Title</th>
                  <th>Product Quantity</th>
                  <th>Unit Price</th>
                  <th>Sub Total Price</th>

                </tr>
              </thead>
              <tbody>

                <?php
                  $total_price = 0;
                ?>

                <?php $__currentLoopData = $order->carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                  <td><?php echo e($loop->index + 1); ?></td>
                  <td>
                    <a href="#"><?php echo e($cart->product->title); ?></a>
                  </td>

                  <td>
                    <?php echo e($cart->product_quantity); ?>

                </td>
                <td><?php echo e($cart->product->price); ?> Taka</td>

                <?php
                  $total_price += $cart->product->price * $cart->product_quantity;
                ?>

                <td><?php echo e($cart->product->price * $cart->product_quantity); ?> Taka</td>

                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td colspan="4"></td>
                  <td>Total Amount : </td>
                  <td colspan="2"> <strong> <?php echo e($total_price); ?> Taka</strong></td>
                </tr>
                <tr>
                  <td colspan="4"></td>
                  <td>Shipping Charge : </td>
                  <td colspan="2"> <strong> <?php echo e($order->shipping_charge); ?> Taka</strong></td>
                </tr>
                <tr>
                  <td colspan="4"></td>
                  <td>Custom Discount : </td>
                  <td colspan="2"> <strong> <?php echo e($order->custom_discount); ?> Taka</strong></td>
                </tr>
                <tr>
                  <td colspan="4"></td>
                  <td>Total Amount : </td>
                  <td colspan="2"> <strong> <?php echo e($total_price + $order->shipping_charge - $order->custom_discount); ?> Taka</strong></td>
                </tr>

              </tbody>
            </table>
            <?php endif; ?>

            <hr>

          </div>


      </div>

  </body>
</html>
<?php /**PATH C:\xampp\htdocs\Ecommerce\resources\views/backend/pages/orders/invoice.blade.php ENDPATH**/ ?>