

<?php $__env->startSection('sub-content'); ?>
  <div class="container">
    <h2>Welcome <?php echo e($user->first_name . ' ' . $user->last_name); ?></h2>
    <p>You can change your profile here....</p>
    <hr>

    <div class="row">
      <div class="col-md-4">
        <div class="card card-body mt-2 pointer" onclick="location.href='<?php echo e(route('user.profile')); ?>'">
          <h4>Update Profile</h4>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.pages.users.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ecommerce\resources\views/frontend/pages/users/dashboard.blade.php ENDPATH**/ ?>