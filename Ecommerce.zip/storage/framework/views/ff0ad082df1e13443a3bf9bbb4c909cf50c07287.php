<?php $__env->startSection('content'); ?>
  <div class="container margin-top-20">
    <h2>Contact</h2>
    <p>Loremipsum dolor smit ansu fati tere amafi diaji afgyhdagt turamma</p>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ecommerce\resources\views/frontend/pages/contact.blade.php ENDPATH**/ ?>