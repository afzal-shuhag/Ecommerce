<footer class="footer-bottom">
  <p class="text-center">&copy; 2020 All rights reserved || Ecommerce</p>
</footer>
<?php /**PATH C:\xampp\htdocs\Ecommerce\resources\views/partials/footer.blade.php ENDPATH**/ ?>