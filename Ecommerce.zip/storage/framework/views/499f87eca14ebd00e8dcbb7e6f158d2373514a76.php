<?php $__env->startSection('content'); ?>
  <div class="container margin-top-20">
    <div class="card card-body">
      <h2>Confirm Items</h2>
      <hr>
      <div class="row">
        <div class="col-md-7 border-right">
          <?php $__currentLoopData = App\Models\Cart::totalCarts(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p>
              <?php echo e($cart->product->title); ?> -
              <strong> <?php echo e($cart->product->price); ?> Taka </strong>
              - <?php echo e($cart->product_quantity); ?> items
            </p>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        <div class="col-md-5">
          <?php
            $total_price = 0;
          ?>
          <?php $__currentLoopData = App\Models\Cart::totalCarts(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php
              $total_price += $cart->product->price * $cart->product_quantity;
          ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <p>Total Price : <strong><?php echo e($total_price); ?></strong> Taka</p>
          <!-- <p>Total Price with shipping cost : <strong><?php echo e($total_price + App\Models\Setting::first()->shipping_cost); ?></strong> Taka</p> -->

        </div>
      </div>
        <p>
          <a href="<?php echo e(route('carts')); ?>"> Change Cart Items</a>
        </p>
    </div>

    <div class="card card-body">
      <h2>Shiping Address</h2>
      <hr>
      <form method="POST" action="<?php echo e(route('checkouts.store')); ?>">
          <?php echo csrf_field(); ?>

          <div class="form-group row">
              <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Reciever Name')); ?></label>

              <div class="col-md-6">
                  <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(Auth::check() ? Auth::user()->first_name . ' ' . Auth::user()->last_name : ''); ?>" required autocomplete="name" autofocus>

                  <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($message); ?></strong>
                      </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
          </div>




          <div class="form-group row">
              <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>

              <div class="col-md-6">
                  <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(Auth::check() ? Auth::user()->email : ''); ?>" required autocomplete="email">

                  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($message); ?></strong>
                      </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
          </div>

          <div class="form-group row">
              <label for="phone_no" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Phone Number')); ?></label>

              <div class="col-md-6">
                  <input id="phone_no" type="text" class="form-control <?php $__errorArgs = ['phone_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="phone_no" value="<?php echo e(Auth::check() ? Auth::user()->phone_no : ''); ?>" required autocomplete="phone_no">

                  <?php $__errorArgs = ['phone_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($message); ?></strong>
                      </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
          </div>



          <div class="form-group row">
              <label for="shipping_address" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Shipping Address')); ?></label>

              <div class="col-md-6">
                  <textarea id="shipping_address" class="form-control <?php $__errorArgs = ['shipping_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="shipping_address" rows="4" required autocomplete="shipping_address"><?php echo e(Auth::check() ? Auth::user()->shipping_address : ''); ?></textarea>

                  <?php $__errorArgs = ['shipping_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($message); ?></strong>
                      </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
          </div>
          <div class="form-group row">
              <label for="message" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Additional Message')); ?></label>

              <div class="col-md-6">
                  <textarea id="message" class="form-control <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="message" rows="4"  autocomplete="message"></textarea>

                  <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($message); ?></strong>
                      </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
          </div>

          <div class="form-group row">
              <label for="payment_method" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Payment Method')); ?></label>

              <div class="col-md-6">
                <select class="form-control" name="payment_method_id" id="payments" required>
                  <option value="">Select a payment method</option>
                  <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($payment->id); ?>"><?php echo e($payment->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  <?php if($payment->short_name == 'cash_on'): ?>
                      <div class="hidden alert alert-success mt-3" id="payment_<?php echo e($payment->short_name); ?>">
                      <h3>
                        Thanks for ordering..... <br>
                        <small>Please pay your bill to our delivery man when you get your products</small>
                      </h3>
                    </div>
                  <?php else: ?>

                        <div class="hidden alert alert-success mt-3" id="payment_<?php echo e($payment->short_name); ?>">
                          <h3>Payment Name : <?php echo e($payment->name); ?></h3> <br>
                          <p>
                            <strong><?php echo e($payment->name); ?> No : <?php echo e($payment->no); ?></strong> <br>
                            <strong>Account type : <?php echo e($payment->type); ?></strong>
                          </p>
                          <div class="">
                            Please Send Your Money to above Bkash Number and write your transaction id..
                          </div>

                        </div>


                  <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <input type="text" name="transaction_id" id="transaction_id" class="form-control hidden" placeholder="Enter transaction code">
              </div>

          </div>
        </div>





          <div class="form-group row mb-0">
              <div class="col-md-6 offset-md-4">
                  <button type="submit" class="btn btn-primary">
                      <?php echo e(__('Order Now')); ?>

                  </button>
              </div>
          </div>
      </form>

        <p>
          <a href="<?php echo e(route('carts')); ?>"> Change Cart Items</a>
        </p>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  <script type="text/javascript">
    $('#payments').change(function(){
      $payment_method = $("#payments").val();
      if($payment_method == 1)
      {
        $('#payment_cash_on').removeClass("hidden");
        $('#payment_bkash').addClass("hidden");
        $('#payment_rocket').addClass("hidden");
      }
      else if ($payment_method == 2)
      {
        $('#payment_bkash').removeClass("hidden");
        $('#payment_cash_on').addClass("hidden");
        $('#payment_rocket').addClass("hidden");
        $('#transaction_id').removeClass("hidden");
      }
      else if ($payment_method == 3)
      {
        $('#payment_rocket').removeClass("hidden");
        $('#payment_bkash').addClass("hidden");
        $('#payment_cash_on').addClass("hidden");
        $('#transaction_id').removeClass("hidden");
      }

   })
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ecommerce\resources\views/frontend/pages/checkouts.blade.php ENDPATH**/ ?>