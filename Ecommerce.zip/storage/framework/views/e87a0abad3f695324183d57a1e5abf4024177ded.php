

<?php $__env->startSection('content'); ?>
<!-- Start of Siderbar + content -->

  <div class="container margin-top-20">
    <div class="row">
      <div class="col-md-4">
      <?php echo $__env->make('frontend.partials.product-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>


      <div class="col-md-8">
          <div class="widget">
            <h3>Searched Products for
              <span class="badge badge-primary"><?php echo e($search); ?></span>
            </h3>
            <div class="row">

              <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <div class="col-md-4">
                <div class="card">
                  <!-- <img class="card-img-top feature-img" src="<?php echo e(asset('images/products/'.'samsung.png')); ?>" alt="Card image"> -->
                  <?php $i = 1; ?>
                  <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($i>0): ?>
                    <a href="<?php echo e(route('products.show', $product->slug)); ?>">
                      <img style ="  min-height: 200px;" class="card-img-top feature-img product_image" src="<?php echo e(asset('images/products/'. $image->image)); ?>" alt="Card image">
                    </a>
                    <?php endif; ?>
                  <?php $i--; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <div class="card-body">
                    <h4 class="card-title">
                       <a href="<?php echo e(route('products.show', $product->slug)); ?>"><?php echo e($product->title); ?></a>
                     </h4>
                    <p class="card-text">Taka - <?php echo e($product->price); ?></p>
                    <?php echo $__env->make('frontend.pages.product.partials.cart-button', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <!-- <a href="#" class="btn btn-outline-warning">Add To Cart</a> -->
                  </div>
                </div>
              </div>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
      </div>
    </div>
  </div>

<!-- End of Siderbar + Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ecommerce\resources\views/frontend/pages/product/search.blade.php ENDPATH**/ ?>