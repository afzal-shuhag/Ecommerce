<div class="row">

  <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

  <div class="col-md-4">
    <div class="card">
      <!-- <img class="card-img-top feature-img" src="<?php echo e(asset('images/products/'.'samsung.png')); ?>" alt="Card image"> -->
      <?php $i = 1; ?>
      <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($i>0): ?>
        <a href="<?php echo e(route('products.show', $product->slug)); ?>">
          <img style ="  min-height: 200px;" class="card-img-top feature-img product_image" src="<?php echo e(asset('images/products/'. $image->image)); ?>" alt="Card image">
        </a>
        <?php endif; ?>
      <?php $i--; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <div class="card-body">
        <h4 class="card-title">
           <a href="<?php echo e(route('products.show', $product->slug)); ?>"><?php echo e($product->title); ?></a>
         </h4>
        <p class="card-text">Taka - <?php echo e($product->price); ?></p>
        <?php echo $__env->make('frontend.pages.product.partials.cart-button', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- <a href="#" class="btn btn-outline-warning">Add To Cart</a> -->
      </div>
    </div>
  </div>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


</div>

<div class="pagination">
    <?php echo e($products->links()); ?>

</div>

<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

  <?php if($category->products()): ?>
<div class="<?php echo e($category->name); ?> mt-5">
  <h3 class="badge badge-info"><?php echo e($category->name); ?></h3>

  <div class="row">
      <?php $__currentLoopData = $category->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-4">

      <div class="card">
        <!-- <img class="card-img-top feature-img" src="<?php echo e(asset('images/products/'.'samsung.png')); ?>" alt="Card image"> -->
        <?php $i = 1; ?>

          <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($i>0): ?>
          <a href="<?php echo e(route('products.show', $product->slug)); ?>">
            <img style ="  min-height: 200px;" class="card-img-top feature-img product_image" src="<?php echo e(asset('images/products/'. $image->image)); ?>" alt="Card image">
          </a>
          <?php endif; ?>
        <?php $i--; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="card-body">
          <h4 class="card-title">
             <a href="<?php echo e(route('products.show', $product->slug)); ?>"><?php echo e($product->title); ?></a>
           </h4>
          <p class="card-text">Taka - <?php echo e($product->price); ?></p>
          <?php echo $__env->make('frontend.pages.product.partials.cart-button', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <!-- <a href="#" class="btn btn-outline-warning">Add To Cart</a> -->
        </div>
      </div>

    </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>


<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\Ecommerce\resources\views/frontend/pages/product/partials/all_products.blade.php ENDPATH**/ ?>